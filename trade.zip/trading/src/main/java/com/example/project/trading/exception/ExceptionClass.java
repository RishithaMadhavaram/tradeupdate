package com.example.project.trading.exception;

public class ExceptionClass extends RuntimeException{
	public ExceptionClass() {
		super("Data is invalid");
	}
}
